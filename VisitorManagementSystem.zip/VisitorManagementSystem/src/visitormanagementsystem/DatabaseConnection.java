package visitormanagementsystem;

public class DatabaseConnection {
    public static final String DB_CONNECTION = "jdbc:mysql://192.168.0.110:3306/project"; 
}
